create view sumar_recetas(cant_recetada, idmedicamento, nombre) as
SELECT sum(d.cantrecetada) AS cant_recetada,
       m.idmedicamento,
       l.nombre
FROM medicamentos m
         JOIN detrecetas d ON d.idmedicamento = m.idmedicamento
         JOIN laboratorios l ON l.idlaboratorio = m.idlaboratorio
GROUP BY m.idmedicamento, l.nombre;

alter table sumar_recetas
    owner to postgres;

