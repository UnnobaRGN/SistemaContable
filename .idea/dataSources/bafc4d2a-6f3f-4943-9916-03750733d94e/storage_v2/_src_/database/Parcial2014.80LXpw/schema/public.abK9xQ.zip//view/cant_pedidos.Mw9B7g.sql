create view cant_pedidos(nombre, cantidad_de_pedidos) as
SELECT f.nombre,
       count(*) AS cantidad_de_pedidos
FROM flete f
         JOIN pedido p ON f.idflete = p.idflete
WHERE p.fechaentrega IS NOT NULL
GROUP BY f.nombre;

alter table cant_pedidos
    owner to postgres;

