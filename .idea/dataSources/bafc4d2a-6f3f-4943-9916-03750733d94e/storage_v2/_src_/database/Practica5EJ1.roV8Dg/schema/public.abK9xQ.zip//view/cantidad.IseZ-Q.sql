create view cantidad(titulo, conta) as
SELECT p.titulo,
       count(a.ejemplar) AS conta
FROM peliculas p
         JOIN ejemplares e ON p.idpelicula = e.pelicula
         JOIN alquilados a ON a.ejemplar = e.idejemplar
WHERE a.fecha_alquiler >= '2011-03-01'::date
  AND a.fecha_alquiler < '2011-04-01'::date
GROUP BY p.titulo;

alter table cantidad
    owner to postgres;

