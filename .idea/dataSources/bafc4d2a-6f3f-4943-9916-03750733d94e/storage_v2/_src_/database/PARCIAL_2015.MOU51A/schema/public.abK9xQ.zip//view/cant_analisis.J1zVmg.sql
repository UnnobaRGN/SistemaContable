create view cant_analisis(cantidad, nombre) as
SELECT count(*) AS cantidad,
       p.nombre
FROM analisis a
         JOIN pacientes p ON a.idpaciente = p.idpaciente
GROUP BY p.nombre;

alter table cant_analisis
    owner to postgres;

